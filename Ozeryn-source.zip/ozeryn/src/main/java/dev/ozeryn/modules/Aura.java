package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import dev.ozeryn.util.Rot;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Aura extends Module {
    public static Aura I;

    public final Setting.Num range = add(new Setting.Num("Range", 3.5, 2, 20, 0.1));
    public final Setting.Mode rotation = add(new Setting.Mode("Rotation", "FT", "Grim", "Spooky Time", "Fun Time", "Noise", "HVH"));
    public final Setting.Num turnSpeed = add(new Setting.Num("Turn Speed", 0, 0, 10, 1));
    public final Setting.Mode critical = add(new Setting.Mode("Critical", "Off", "Always", "Only Space"));
    public final Setting.Mode sprint = add(new Setting.Mode("Sprint", "Keep", "Reset"));
    public final Setting.Mode weapon = add(new Setting.Mode("Auto Weapon", "Silent", "Normal", "None"));
    public final Setting.Bool smooth = add(new Setting.Bool("Smooth", true));
    public final Setting.Bool mobs = add(new Setting.Bool("Target Mobs", false));

    public LivingEntity target;
    public float rotYaw, rotPitch;
    boolean hasRot, jumpForced;
    int tick, critWait;

    // mode state
    boolean grimInner; int grimUpd; int hwC;
    int spRegion; long spNext; double spPhase; int spId = -1;

    public Aura() {
        super("Aura", Category.COMBAT);
        I = this;
        turnSpeed.showIf(() -> rotation.is("Fun Time"));
    }

    @Override public void onDisable() { target = null; hasRot = false; }

    // ------------------------------------------------------------------ target
    LivingEntity find(ClientPlayerEntity p) {
        LivingEntity best = null; double bd = Double.MAX_VALUE;
        Vec3d eye = p.getEyePos();
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || le.isSpectator()) continue;
            boolean player = e instanceof net.minecraft.entity.player.PlayerEntity;
            if (!player && !(mobs.value && e instanceof MobEntity)) continue;
            double d = Rot.dist(eye, e.getBoundingBox());
            if (d > range.value) continue;
            if (d < bd) { bd = d; best = le; }
        }
        return best;
    }

    // ------------------------------------------------------------------ tick
    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { target = null; return; }
        tick++;
        if (jumpForced) { mc.options.jumpKey.setPressed(false); jumpForced = false; }

        target = find(p);
        if (target == null) { hasRot = false; critWait = 0; return; }
        if (!hasRot) { rotYaw = p.getYaw(); rotPitch = p.getPitch(); hasRot = true; }

        if (ElytraTarget.I.isActive(p)) { ElytraTarget.I.tick(p, target); return; }

        Vec3d eye = p.getEyePos();
        Box bb = target.getBoundingBox();
        double dist = Rot.dist(eye, bb);
        boolean inRange = dist <= range.value;
        boolean cd = p.getAttackCooldownProgress(0.5f) >= 0.9f;
        boolean b = inRange && cd && critOk(p);

        if (critical.is("Always") && inRange && cd && p.isOnGround() && !p.isFallFlying()) {
            mc.options.jumpKey.setPressed(true); jumpForced = true;
        }

        Vec3d point = pointFor(eye, target);
        float[] aim = Rot.to(eye, point);
        stepRotation(p, aim, b);

        if (RotationMod.I.enabled && RotationMod.I.focus() && !p.isFallFlying()) {
            // handled in RotationMod
        }
        if (ClientLook.I.enabled) { p.setYaw(rotYaw); p.setPitch(rotPitch); }

        if (b) {
            // make sure the sent rotation really hits the box
            Vec3d look = Vec3d.fromPolar(rotPitch, rotYaw);
            if (bb.expand(0.05).raycast(eye, eye.add(look.multiply(range.value + 1))).isEmpty()) {
                rotYaw = aim[0]; rotPitch = aim[1];
            }
            attack(target, rotYaw, rotPitch);
        }
    }

    Vec3d pointFor(Vec3d eye, LivingEntity t) {
        Box bb = t.getBoundingBox();
        if (smooth.value && t.isFallFlying()) {
            Vec3d v = Rot.motion(t);
            Vec3d dir = v.lengthSquared() > 1e-4 ? v.normalize() : Vec3d.ZERO;
            return Rot.clampToBox(bb.getCenter().subtract(dir.multiply(0.5)), bb);
        }
        if (rotation.is("Spooky Time")) return spooky(eye, t);
        return Rot.nearest(eye, bb, 0.72);
    }

    boolean critOk(ClientPlayerEntity p) {
        if (critical.is("Off")) return true;
        if (p.isFallFlying() || p.isTouchingWater() || p.isClimbing() || p.hasVehicle()) return true;
        boolean gate = critical.is("Always") || mc.options.jumpKey.isPressed() || !p.isOnGround();
        if (!gate) return true;
        boolean ok = p.fallDistance > 0.0f && !p.isOnGround();
        if (ok) { critWait = 0; return true; }
        if (++critWait >= 10) { critWait = 0; return true; }
        return false;
    }

    // ------------------------------------------------------------------ rotation modes
    void stepRotation(ClientPlayerEntity p, float[] aim, boolean b) {
        float dy = MathHelper.wrapDegrees(aim[0] - rotYaw);
        float dp = aim[1] - rotPitch;
        double sy = 0, sp = 0;
        double M = Math.sin(tick * 0.17), P = Math.sin(tick * 0.31) * 0.5;
        switch (rotation.get()) {
            case "FT" -> {
                if (b) { sy = dy + Rot.g(2.0); sp = Rot.sat(dp, 8) + 4 * P + Rot.g(1.0); }
                else {
                    double r = 40 + Rot.RND.nextDouble() * 20;
                    sy = Rot.sat(dy, r) + 10 * M + Rot.g(2.5);
                    sp = Rot.sat(dp, 8) + 4 * P + Rot.g(1.0);
                }
            }
            case "Grim" -> {
                grimUpd++;
                if (grimUpd > 1 && !b) { grimInner = true; }
                else {
                    double f = grimInner ? 7 + Rot.RND.nextDouble() * 6 : 0;
                    if (b) { sy = dy; sp = dp; grimInner = false; grimUpd = 0; }
                    else { sy = f; sp = p.getVelocity().y > 0 ? -f : f; }
                }
            }
            case "Spooky Time" -> {
                double k = b ? 1.0 : 0.65;
                sy = MathHelper.clamp(dy * k, -60, 60) + Rot.g(0.4);
                sp = MathHelper.clamp(dp * (k - 0.05), -30, 30) + Rot.g(0.2);
            }
            case "Fun Time" -> {
                double ts = turnSpeed.value;
                double lim = ts <= 0 ? 360 : ts * 6;
                boolean air = target != null && target.isFallFlying();
                double jit = air ? 0 : Math.sin(tick * 1.9) * 3.0 + Rot.g(0.8);
                sy = MathHelper.clamp(dy, -lim, lim) + jit;
                sp = MathHelper.clamp(dp, -lim / 2, lim / 2) + jit * 0.4;
            }
            case "Noise" -> {
                sy = Rot.sat(dy, 45) + (b ? 0 : Rot.g(5));
                sp = Rot.sat(dp, 5) + (b ? 0 : Rot.g(1));
            }
            case "HVH" -> {
                hwC--;
                if (b) hwC = 2;
                if (hwC > 0) {
                    double r = Math.hypot(Math.abs(dy), Math.abs(dp));
                    if (r < 1e-4) { sy = dy; sp = dp; }
                    else {
                        double ly = 360 * Math.abs(dy) / r, lp = 360 * Math.abs(dp) / r;
                        sy = MathHelper.clamp(dy, -ly, ly) + Rot.g(0.6);
                        sp = MathHelper.clamp(dp, -lp, lp) + Rot.g(0.3);
                    }
                } else hwC = 0;
            }
        }
        rotYaw = MathHelper.wrapDegrees(rotYaw + (float) sy);
        rotPitch = MathHelper.clamp(rotPitch + (float) sp, -90f, 90f);
    }

    Vec3d spooky(Vec3d eye, LivingEntity t) {
        long now = System.currentTimeMillis();
        if (t.getId() != spId || now >= spNext) {
            spId = t.getId();
            double r = Rot.RND.nextDouble();
            spRegion = r < 0.46 ? 0 : r < 0.76 ? 1 : r < 0.92 ? 2 : 3;
            spNext = now + 58 + Rot.RND.nextInt(147);
            spPhase = Rot.RND.nextDouble() * Math.PI * 2;
        }
        Box bb = t.getBoundingBox();
        Vec3d vt = Rot.motion(t), vp = Rot.motion(mc.player);
        double vx = vt.x - 0.42 * vp.x, vz = vt.z - 0.42 * vp.z;
        double V = Math.hypot(vx, vz), D = Rot.dist(eye, bb);
        double q = MathHelper.clamp(D * 0.46 + V * 5.8, 0.85, 5.2);
        double[] yf = {0.75, 0.82, 0.60, 0.93};
        Vec3d c = bb.getCenter();
        Vec3d p0 = new Vec3d(c.x, bb.minY + (bb.maxY - bb.minY) * yf[spRegion], c.z);
        Vec3d pp = new Vec3d(p0.x + vx * q, p0.y + vt.y * MathHelper.clamp(0.42 * q, 0, 1.45), p0.z + vz * q);
        pp = Rot.clampToBox(pp, bb);
        double a = 0.046, tm = now;
        pp = pp.add(Math.sin(tm * 0.0105 + spPhase) * bb.getXLength() * a,
                Math.cos(tm * 0.0073 + spPhase * 0.73) * bb.getYLength() * a * 0.28,
                Math.sin(tm * 0.0121 + spPhase * 1.31) * bb.getZLength() * a);
        return Rot.clampToBox(pp, bb);
    }

    // ------------------------------------------------------------------ attack
    public int bestWeaponSlot(ClientPlayerEntity p) {
        int best = -1; double bs = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isEmpty()) continue;
            int sharp = EnchantmentHelper.getLevel(Enchantments.SHARPNESS, s);
            double score = sharp * 100.0;
            if (s.getItem() instanceof SwordItem sw) score += 10 + sw.getAttackDamage();
            else if (s.getItem() instanceof AxeItem ax) score += 8 + ax.getAttackDamage();
            if (score > bs && score > 0) { bs = score; best = i; }
        }
        return best;
    }

    public void attack(LivingEntity t, float yaw, float pitch) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        int old = p.getInventory().selectedSlot;
        boolean swapped = false;
        if (!weapon.is("None")) {
            int s = bestWeaponSlot(p);
            if (s >= 0 && s != old) { p.getInventory().selectedSlot = s; swapped = true; }
        }
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround()));
        boolean resetSprint = sprint.is("Reset") && p.isSprinting();
        if (resetSprint) p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
        if (resetSprint) p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_SPRINTING));
        if (swapped && weapon.is("Silent")) p.getInventory().selectedSlot = old;
    }
}
