package dev.ozeryn.modules;

import dev.ozeryn.core.*;

public class AutoSprint extends Module {
    public AutoSprint() { super("Auto Sprint", Category.MISC); }

    @Override public void onTick() {
        var p = mc.player;
        if (p == null) return;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision && p.getHungerManager().getFoodLevel() > 6)
            p.setSprinting(true);
    }
}
