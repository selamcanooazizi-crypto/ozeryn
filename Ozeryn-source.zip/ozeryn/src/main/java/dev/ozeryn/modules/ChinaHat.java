package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import dev.ozeryn.util.R3;
import dev.ozeryn.util.Rot;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.util.math.Vec3d;

public class ChinaHat extends Module {
    public final Setting.Num radius = add(new Setting.Num("Radius", 0.55, 0.3, 1.0, 0.05));
    public final Setting.Num height = add(new Setting.Num("Height", 0.3, 0.15, 0.6, 0.05));
    public final Setting.Num alpha = add(new Setting.Num("Opacity", 120, 30, 255, 5));

    public ChinaHat() { super("China Hat", Category.RENDER); }

    @Override
    public void onWorld(WorldRenderContext c) {
        if (mc.player == null || !c.camera().isThirdPerson()) return;
        Vec3d p = Rot.lerpPos(mc.player, c.tickDelta());
        double y = mc.player.getHeight() + (mc.player.isSneaking() ? -0.1 : 0.0) - 0.02;
        R3.begin();
        R3.cone(c.matrixStack(), c.camera(), p.add(0, y, 0), radius.f(), height.f(), Theme.argb((int) alpha.value), Theme.argb((int) alpha.value / 2));
        R3.end();
    }
}
