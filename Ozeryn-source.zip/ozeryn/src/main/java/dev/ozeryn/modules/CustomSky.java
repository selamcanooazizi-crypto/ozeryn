package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import dev.ozeryn.util.R3;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

public class CustomSky extends Module {
    public final Setting.Num count = add(new Setting.Num("Orbs", 140, 40, 400, 10));
    public final Setting.Num size = add(new Setting.Num("Size", 1.0, 0.4, 2.5, 0.1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.2, 3.0, 0.1));

    public CustomSky() { super("Custom Sky", Category.RENDER); }

    @Override
    public void onWorld(WorldRenderContext c) {
        if (mc.player == null) return;
        Vec3d cp = c.camera().getPos();
        double time = Util.getMeasuringTimeMs() / 1000.0 * speed.value;
        Random rr = new Random(1337);
        R3.begin();
        for (int i = 0; i < (int) count.value; i++) {
            double theta = rr.nextDouble() * Math.PI * 2;
            double phi = Math.acos(2 * rr.nextDouble() - 1);
            double rad = 28 + rr.nextDouble() * 55;
            double sz = (0.25 + rr.nextDouble() * 0.9) * size.value;
            double ph = rr.nextDouble() * 6.28;
            double th = theta + time * (0.03 + 0.02 * (i % 4));
            double x = Math.sin(phi) * Math.cos(th) * rad;
            double z = Math.sin(phi) * Math.sin(th) * rad;
            double y = Math.cos(phi) * rad * 0.8 + Math.sin(time * 0.7 + ph) * 2.0;
            int a = (int) (110 + 90 * Math.sin(time + ph));
            int col = (i % 5 == 0) ? 0xFFFFFF : Theme.rgb();
            Vec3d p = cp.add(x, y, z);
            R3.orb(c.matrixStack(), c.camera(), p, (float) sz, (a << 24) | col);
            R3.orb(c.matrixStack(), c.camera(), p, (float) (sz * 2.6), (28 << 24) | col);
        }
        R3.end();
    }
}
