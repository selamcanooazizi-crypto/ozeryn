package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import dev.ozeryn.util.R2;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public class ArrayListHud extends Module {
    public ArrayListHud() { super("Arraylist", Category.RENDER); enabled = true; }

    @Override
    public void onHud(DrawContext c, float delta) {
        List<Module> on = new ArrayList<>();
        for (Module m : Modules.all) if (m.enabled && m != this && m.category != Category.CLIENT) on.add(m);
        on.sort((a, b) -> R2.w(b.name) - R2.w(a.name));
        int y = 4, right = c.getScaledWindowWidth() - 4;
        for (Module m : on) {
            int w = R2.w(m.name) + 10;
            R2.rrect(c, right - w, y, w, 13, 3, 0x960A0A0E);
            c.fill(right - 2, y + 2, right, y + 11, Theme.argb(255));
            R2.text(c, m.name, right - w + 4, y + 1, Theme.argb(255));
            y += 14;
        }
    }
}
