package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.ParticlesMode;

public class FpsBoost extends Module {
    ParticlesMode op; CloudRenderMode oc; boolean os; int ob; double oe;

    public FpsBoost() { super("FPS Boost", Category.RENDER); }

    @Override public void onEnable() {
        if (mc.options == null) return;
        op = mc.options.getParticles().getValue();
        oc = mc.options.getCloudRenderMode().getValue();
        os = mc.options.getEntityShadows().getValue();
        ob = mc.options.getBiomeBlendRadius().getValue();
        oe = mc.options.getEntityDistanceScaling().getValue();
        mc.options.getParticles().setValue(ParticlesMode.MINIMAL);
        mc.options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        mc.options.getEntityShadows().setValue(false);
        mc.options.getBiomeBlendRadius().setValue(0);
        mc.options.getEntityDistanceScaling().setValue(0.6);
    }

    @Override public void onDisable() {
        if (mc.options == null || op == null) return;
        mc.options.getParticles().setValue(op);
        mc.options.getCloudRenderMode().setValue(oc);
        mc.options.getEntityShadows().setValue(os);
        mc.options.getBiomeBlendRadius().setValue(ob);
        mc.options.getEntityDistanceScaling().setValue(oe);
    }
}
