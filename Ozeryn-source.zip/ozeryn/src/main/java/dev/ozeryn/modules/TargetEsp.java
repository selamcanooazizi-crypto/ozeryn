package dev.ozeryn.modules;

import dev.ozeryn.core.*;
import dev.ozeryn.util.R2;
import dev.ozeryn.util.R3;
import dev.ozeryn.util.Rot;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class TargetEsp extends Module {
    public static TargetEsp I;

    public final Setting.Mode style = add(new Setting.Mode("Style", "Orbs", "Ring"));
    public final Setting.Mode color = add(new Setting.Mode("Color", "White", "Theme", "Rainbow"));
    public final Setting.Num count = add(new Setting.Num("Count", 4, 2, 10, 1));
    public final Setting.Num size = add(new Setting.Num("Size", 1.0, 0.5, 2.0, 0.1));
    public final Setting.Num speed = add(new Setting.Num("Speed", 1.0, 0.3, 3.0, 0.1));
    public final Setting.Bool hud = add(new Setting.Bool("Target HUD", true));
    public final Setting.Num hudAlpha = add(new Setting.Num("HUD Opacity", 170, 0, 255, 5));

    float hpAnim = -1;
    int lastId = -1;

    public TargetEsp() { super("Target ESP", Category.RENDER); I = this; enabled = true; }

    int rgb(float t) {
        if (color.is("Theme")) return Theme.rgb();
        if (color.is("Rainbow")) return java.awt.Color.HSBtoRGB(t * 0.1f % 1f, 0.6f, 1f) & 0xFFFFFF;
        return 0xFFFFFF;
    }

    @Override
    public void onWorld(WorldRenderContext c) {
        Aura a = Aura.I;
        if (!a.enabled || a.target == null) return;
        LivingEntity t = a.target;
        Vec3d base = Rot.lerpPos(t, c.tickDelta());
        double time = Util.getMeasuringTimeMs() / 1000.0 * speed.value;
        boolean hurt = t.hurtTime > 0;
        double rad = Math.max(0.4, t.getWidth() * 0.85) * size.value;
        double h = t.getHeight();
        R3.begin();
        int n = (int) count.value;
        if (style.is("Orbs")) {
            for (int i = 0; i < n; i++) {
                for (int k = 0; k < 7; k++) {
                    double ang = time * 2.2 - k * 0.11 + i * Math.PI * 2 / n;
                    double y = h * (0.5 + 0.42 * Math.sin(time * 1.4 + i * 1.7 - k * 0.05));
                    Vec3d p = base.add(Math.cos(ang) * rad, y, Math.sin(ang) * rad);
                    int col = hurt ? R2.mix(0xFFFFFF & rgb((float) time), 0xFF3030, 0.7f) & 0xFFFFFF : rgb((float) (time + i));
                    int alpha = (int) (230 * Math.pow(1 - k / 7.0, 1.6));
                    R3.orb(c.matrixStack(), c.camera(), p, (float) (0.085 * size.value * (1 - k * 0.07)), (alpha << 24) | col);
                    if (k == 0) R3.orb(c.matrixStack(), c.camera(), p, (float) (0.2 * size.value), (70 << 24) | col);
                }
            }
        } else {
            int pts = 36;
            for (int i = 0; i < pts; i++) {
                double ang = i * Math.PI * 2 / pts + time;
                double y = h * (0.5 + 0.5 * Math.sin(time * 1.3));
                Vec3d p = base.add(Math.cos(ang) * rad, y, Math.sin(ang) * rad);
                int col = hurt ? 0xFF3030 : rgb((float) (time + i * 0.05));
                R3.orb(c.matrixStack(), c.camera(), p, (float) (0.07 * size.value), (200 << 24) | col);
                R3.orb(c.matrixStack(), c.camera(), p.add(0, 0.0, 0), (float) (0.16 * size.value), (50 << 24) | col);
            }
        }
        R3.end();
    }

    @Override
    public void onHud(DrawContext c, float delta) {
        Aura a = Aura.I;
        if (!hud.value || !a.enabled || a.target == null) { hpAnim = -1; return; }
        LivingEntity t = a.target;
        if (t.getId() != lastId || hpAnim < 0) { lastId = t.getId(); hpAnim = t.getHealth(); }
        hpAnim += (t.getHealth() - hpAnim) * 0.12f;

        int w = 138, h = 46;
        int x = c.getScaledWindowWidth() / 2 + 70, y = c.getScaledWindowHeight() / 2 + 40;
        int ba = (int) hudAlpha.value;
        R2.rrect(c, x, y, w, h, 6, (ba << 24) | 0x0A0A0E);
        int accent = Theme.argb(255);
        // head
        if (t instanceof AbstractClientPlayerEntity pl) {
            PlayerSkinDrawer.draw(c, pl.getSkinTexture(), x + 6, y + 7, 32);
        } else {
            R2.rrect(c, x + 6, y + 7, 32, 32, 4, Theme.argb(120));
            String ch = t.getName().getString().substring(0, 1).toUpperCase();
            R2.text(c, ch, x + 6 + 16 - R2.w(ch) / 2, y + 17, 0xFFFFFFFF);
        }
        String name = t.getName().getString();
        if (name.length() > 14) name = name.substring(0, 14);
        R2.text(c, name, x + 44, y + 6, 0xFFFFFFFF);
        float max = Math.max(1f, t.getMaxHealth());
        float frac = MathHelper.clamp(hpAnim / max, 0f, 1f);
        R2.text(c, String.format("%.1f", t.getHealth()) + " HP", x + 44, y + 19, 0xFFB5B5C0);
        int bx = x + 44, by = y + 34, bw = w - 52;
        R2.rrect(c, bx, by, bw, 5, 2, 0x40FFFFFF);
        R2.rrect(c, bx, by, Math.max(3, (int) (bw * frac)), 5, 2, accent);
    }
}
