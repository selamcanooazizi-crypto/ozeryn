package dev.ozeryn.core;

public final class Theme {
    public static final String[] NAMES = {"Ice", "Violet", "Orchid", "Rose", "Crimson", "Amber", "Lime", "Mint", "Cyan", "Mono"};
    public static final int[] COLORS = {0x4DA3FF, 0x8B5CF6, 0xD946EF, 0xFF4D8D, 0xFF3B3B, 0xFFB020, 0x84F060, 0x2DE0A5, 0x22D3EE, 0xE5E7EB};
    public static int index = 1;

    public static int rgb() { return COLORS[index]; }
    public static int argb(int a) { return (a << 24) | rgb(); }
    public static int darker(float f) {
        int c = rgb();
        int r = (int) (((c >> 16) & 255) * f), g = (int) (((c >> 8) & 255) * f), b = (int) ((c & 255) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
