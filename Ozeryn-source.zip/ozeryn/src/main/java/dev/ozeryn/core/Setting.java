package dev.ozeryn.core;

import java.util.function.BooleanSupplier;

public abstract class Setting {
    public final String name;
    public BooleanSupplier visible = () -> true;
    protected Setting(String n) { name = n; }
    public Setting showIf(BooleanSupplier s) { visible = s; return this; }

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String n, boolean v) { super(n); value = v; }
    }

    public static class Num extends Setting {
        public double value, min, max, step;
        public Num(String n, double v, double min, double max, double step) {
            super(n); this.value = v; this.min = min; this.max = max; this.step = step;
        }
        public void set(double v) {
            v = Math.max(min, Math.min(max, v));
            value = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, value));
        }
        public float f() { return (float) value; }
    }

    public static class Mode extends Setting {
        public final String[] modes;
        public int index;
        public Mode(String n, String... m) { super(n); modes = m; }
        public String get() { return modes[index]; }
        public boolean is(String s) { return modes[index].equals(s); }
        public void next(int d) { index = (index + d + modes.length) % modes.length; }
    }
}
