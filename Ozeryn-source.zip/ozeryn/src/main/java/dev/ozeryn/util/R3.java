package dev.ozeryn.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class R3 {
    public static void begin() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
    }

    public static void end() {
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    /** Soft camera-facing disc. argb = center colour, edge fades out. */
    public static void orb(MatrixStack ms, Camera cam, Vec3d p, float r, int argb) {
        ms.push();
        Vec3d c = cam.getPos();
        ms.translate(p.x - c.x, p.y - c.y, p.z - c.z);
        ms.multiply(cam.getRotation());
        Matrix4f m = ms.peek().getPositionMatrix();
        int a = (argb >>> 24) & 255, rr = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        BufferBuilder bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        bb.vertex(m, 0, 0, 0).color(rr, g, b, a).next();
        int seg = 18;
        for (int i = 0; i <= seg; i++) {
            double ang = i * Math.PI * 2 / seg;
            bb.vertex(m, (float) (Math.cos(ang) * r), (float) (Math.sin(ang) * r), 0).color(rr, g, b, (int) (a * 0.2f)).next();
        }
        BufferRenderer.drawWithGlobalProgram(bb.end());
        ms.pop();
    }

    /** Cone (china hat) in world axes, base centre at p. */
    public static void cone(MatrixStack ms, Camera cam, Vec3d p, float radius, float height, int argb, int edgeArgb) {
        ms.push();
        Vec3d c = cam.getPos();
        ms.translate(p.x - c.x, p.y - c.y, p.z - c.z);
        Matrix4f m = ms.peek().getPositionMatrix();
        BufferBuilder bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        bb.vertex(m, 0, height, 0).color((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, (argb >>> 24) & 255).next();
        int seg = 40;
        for (int i = 0; i <= seg; i++) {
            double ang = i * Math.PI * 2 / seg;
            bb.vertex(m, (float) (Math.cos(ang) * radius), 0, (float) (Math.sin(ang) * radius))
                    .color((edgeArgb >> 16) & 255, (edgeArgb >> 8) & 255, edgeArgb & 255, (edgeArgb >>> 24) & 255).next();
        }
        BufferRenderer.drawWithGlobalProgram(bb.end());
        ms.pop();
    }
}
