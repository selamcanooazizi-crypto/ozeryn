package dev.ozeryn.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class R2 {
    public static final Style FONT = Style.EMPTY.withFont(new Identifier("ozeryn", "main"));

    private static TextRenderer tr() { return MinecraftClient.getInstance().textRenderer; }
    private static Text t(String s) { return Text.literal(s).setStyle(FONT); }

    public static int w(String s) { return tr().getWidth(t(s)); }
    public static int h() { return 11; }
    public static void text(DrawContext c, String s, int x, int y, int color) { c.drawText(tr(), t(s), x, y, color, false); }
    public static void textShadow(DrawContext c, String s, int x, int y, int color) { c.drawText(tr(), t(s), x, y, color, true); }

    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { c.fill(x, y, x + w, y + h, color); return; }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    public static int alpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }

    public static int mix(int c1, int c2, float t) {
        int r = (int) (((c1 >> 16) & 255) * (1 - t) + ((c2 >> 16) & 255) * t);
        int g = (int) (((c1 >> 8) & 255) * (1 - t) + ((c2 >> 8) & 255) * t);
        int b = (int) ((c1 & 255) * (1 - t) + (c2 & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
