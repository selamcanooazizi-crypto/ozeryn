# Ozeryn (Minecraft 1.20.1 Fabric)

Menü: **Sağ Shift**. Sol tık = modül aç/kapa, sağ tık = ayarları aç. Altta 10 tema rengi var.

## Derleme (telefondan)
1. Bu klasörü GitHub'a yükle.
2. Actions > build > Run workflow.
3. Artifacts > Ozeryn içinden JAR'ı indir, Fabric 1.20.1 mods klasörüne at (Fabric API şart).

## Modüller
- Combat: Aura, Elytra Target
- Render: Target ESP (+Target HUD), Watermark, China Hat, Custom Sky, FPS Boost, Arraylist
- Misc: Fullbright, Auto Sprint
- Client: Rotation (Free/Focus), ClientLook

Watermark: T ile chat'i aç, sol tık basılı tutup sürükle.
Font: Poppins (SIL OFL lisanslı).
